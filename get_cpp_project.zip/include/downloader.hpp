#pragma once
#include <iostream>
#include <cstdlib>

void download_file(const std::string& url, const std::string& output, bool print = false) {
    std::string command = "curl -s -L '" + url + "' -o '" + output + "'";
    int result = system(command.c_str());

    if (result != 0) {
        std::cerr << "Failed to download from " << url << "\n";
        return;
    }

    if (print) {
        std::string show = "cat '" + output + "'";
        system(show.c_str());
    } else {
        std::cout << "Downloaded: " << output << "\n";
    }
}
