#include <iostream>
#include <string>
#include "downloader.hpp"

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "Usage: get -i <package> or get -d <package>\n";
        return 1;
    }

    std::string command = argv[1];
    std::string name = argv[2];
    std::string base_url = "https://kullaniciadi.github.io/get-repo/repo/" + name + "/";

    if (command == "-i") {
        std::string tarball_url = base_url + name + ".tar.gz";
        download_file(tarball_url, name + ".tar.gz");
    } else if (command == "-d") {
        std::string desc_url = base_url + name + "-description.txt";
        download_file(desc_url, "/tmp/desc.txt", true);
    } else {
        std::cerr << "Unknown command: " << command << "\n";
        return 1;
    }

    return 0;
}
